package com.mendix.test.exception;

public class CreateClientException extends BaseException {
    public CreateClientException(String message) {
        super(message);
    }
}
