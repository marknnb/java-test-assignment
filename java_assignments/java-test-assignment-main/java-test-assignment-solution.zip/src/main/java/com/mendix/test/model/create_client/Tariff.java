package com.mendix.test.model.create_client;

public enum Tariff {
    FREE,
    STANDARD,
    PREMIUM
}
