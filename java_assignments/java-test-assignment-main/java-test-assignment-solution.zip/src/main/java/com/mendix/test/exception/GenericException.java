package com.mendix.test.exception;

public class GenericException extends BaseException {
    public GenericException(String message) {
        super(message);
    }
}
