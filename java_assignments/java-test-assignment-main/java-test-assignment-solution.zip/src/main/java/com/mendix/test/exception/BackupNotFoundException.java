package com.mendix.test.exception;

public class BackupNotFoundException extends BaseException {
    public BackupNotFoundException(String message) {
        super(message);
    }
}
