package com.mendix.test.exception;

public class ClientNotFoundException extends BaseException {
    public ClientNotFoundException(String message) {
        super(message);
    }
}
