package com.mendix.test.model.backup;

public enum Status {
    IN_PROGRESS,
    DONE,
    FAILED
}
