package com.mendix.test.exception;

public class BaseException extends RuntimeException {
    public BaseException(String message) {
        super(message);
    }
}
