package com.mendix.test.exception;

public class CreateBackupException extends BaseException {
    public CreateBackupException(String message) {
        super(message);
    }
}
