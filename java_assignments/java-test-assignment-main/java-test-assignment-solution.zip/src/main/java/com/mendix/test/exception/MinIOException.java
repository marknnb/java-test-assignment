package com.mendix.test.exception;

public class MinIOException extends BaseException {
    public MinIOException(String message) {
        super(message);
    }
}
