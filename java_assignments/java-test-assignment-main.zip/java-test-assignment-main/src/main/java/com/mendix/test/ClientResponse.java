package com.mendix.test;

import java.util.List;

public class ClientResponse {

    public ClientResponse() {
    }

    public ClientData clientData;
    public TariffData tariffData;
    public List<BackupData> backupDataList;
}
