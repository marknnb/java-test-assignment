package com.mendix.test;

public class ClientData {

    public String id;
    public String credentials;
    public String tariff;

}
