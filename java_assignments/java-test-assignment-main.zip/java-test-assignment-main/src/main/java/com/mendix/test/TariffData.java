package com.mendix.test;

public class TariffData {
}
