package com.mendix.test;

public class BackupData {
}
