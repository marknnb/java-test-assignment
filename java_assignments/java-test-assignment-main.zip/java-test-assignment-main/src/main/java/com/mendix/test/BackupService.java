package com.mendix.test;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface BackupService {

   public ClientData getClientData(String clientId);
   public TariffData getTariffData(String tariffName);
   public List<BackupData> getBackupsData(String clientId);
}
