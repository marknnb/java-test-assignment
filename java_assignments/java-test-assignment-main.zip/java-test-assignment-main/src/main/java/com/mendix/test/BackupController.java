package com.mendix.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class BackupController {

    @Autowired
    private BackupService backupService;

    @GetMapping("/client/{client_id}")
    public ResponseEntity<ClientResponse> getClientInfo(@PathVariable(name = "client_id") String clientId){

        ClientData clientData = backupService.getClientData(clientId);
        TariffData tariffData = backupService.getTariffData(clientData.tariff);
        List<BackupData> backupsData = backupService.getBackupsData(clientId);

        ClientResponse clientResponse = new ClientResponse();
        clientResponse.backupDataList = backupsData;
        clientResponse.clientData = clientData;
        clientResponse.tariffData = tariffData;

        return ResponseEntity.ok(clientResponse);
    }
}
